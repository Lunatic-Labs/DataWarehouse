class BaseService:
    pass
